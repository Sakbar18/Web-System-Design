package user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class usercon {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	
	public usercon() {
		
		try {
			String url = "jdbc:mysql://localhost:3306/web_sys?useUnicode=true&characterEncoding=UTF-8";
			String user = "root";
			String passwd = "1234";
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, passwd);
			conn.prepareStatement("SET NAMES utf8mb4").execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int login(String email, String passwd) {
		String sql = "SELECT passwd FROM user WHERE email = ?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, email);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if(rs.getString(1).equals(passwd))
					return 1; // 로그인 성공
				else 
					return 0; // 비밀번호 불일치 
			}
			return -1; // 아이디 없음
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -2; // 데이터 베이스 오류
	}
	public int join(user user) {
		String sql = "INSERT INTO user (user_name, nickname, email, passwd, user_ad, phone) VALUES (?, ?, ?, ?, ?, ?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUser_name());
			pstmt.setString(2, user.getNickname());
			pstmt.setString(3, user.getEmail());
			pstmt.setString(4, user.getPasswd());
			pstmt.setString(5, user.getUser_ad());
			pstmt.setString(6, user.getPhone());
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류임 
	}
}
