package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BbsDAO {
	private Connection conn;
	private ResultSet rs;
	
	
	public BbsDAO() {
		try {
			String url = "jdbc:mysql://localhost:3306/web_sys";
			String user = "root";
			String passwd = "1234";
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, passwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// 현재의 시간을 가져오는 함수
	public String getDate() {
		String SQL = "SELECT NOW()";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	public int getNext() { // auto increment로 대체 가능할듯
		String SQL = "SELECT bbsID FROM BBS ORDER BY bbsID DESC ";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // 현재 게시물이 첫 번째 게시물인 경우 1부여 
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public int write(String bbsTitle, String bbs_phone, String bbsContent, String deadline, String category, String file, String salary, String user_id) {
		String SQL = "INSERT INTO BBS(bbsID,bbsTitle,user_id,bbsDate,bbsContent,bbsAvailable,salary,category,deadline,file,bbs_phone) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, bbsTitle);
			pstmt.setString(3, user_id);
			pstmt.setString(4, getDate());
			pstmt.setString(5, bbsContent);
			pstmt.setInt(6, 1);
			pstmt.setString(7, salary);
			pstmt.setString(8, category);
			pstmt.setString(9, deadline);
			pstmt.setString(10, file);
			pstmt.setString(11, bbs_phone);
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public ArrayList<Bbs> getList(int pageNumber){
		String SQL = "SELECT * FROM BBS WHERE bbsID < ? AND bbsAvailable = 1 ORDER BY bbsID DESC LIMIT 10";
		ArrayList<Bbs> list = new ArrayList<Bbs>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Bbs bbs = new Bbs();
				bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUser_id(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				bbs.setSalary(rs.getString(7));
				bbs.setCategory(rs.getString(8));
				bbs.setDeadline(rs.getString(9));
				bbs.setFile(rs.getString(10));
				bbs.setBbs_phone(rs.getString(11));
				list.add(bbs);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	// 페이징 처리를 위해 존재하는 함수
	public boolean nextPage(int pageNumber) {
		String SQL = "SELECT * FROM BBS WHERE bbsID < ? AND bbsAvailable = 1";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public Bbs getBbs(int bbsID) {
	    String SQL = "SELECT * FROM BBS WHERE bbsID = ?";
	    try {
	        PreparedStatement pstmt = conn.prepareStatement(SQL);
	        pstmt.setInt(1, bbsID);
	        rs = pstmt.executeQuery();
	        if (rs.next()) {
	            Bbs bbs = new Bbs();
	            bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUser_id(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				bbs.setSalary(rs.getString(7));
				bbs.setCategory(rs.getString(8));
				bbs.setDeadline(rs.getString(9));
				bbs.setBbs_phone(rs.getString(10));
				bbs.setFile(rs.getString(11));
	            return bbs;
	        } else {
	            return null; // 레코드가 없을 경우 null 반환
	        }
	    } catch(Exception e) {
	        e.printStackTrace();
	    }
	    return null;
	}

	// 나중에 파일도 업뎃 하고 싶으면 추가
	public int update(int bbsID, String bbsTitle, String bbsContent, String salary, String deadline, String category, String file, String bbs_phone) {
		String SQL = "UPDATE BBS SET bbsTitle = ?, bbsContent = ?, salary = ?, deadline = ?, category = ?, file = ?, bbs_phone = ?  WHERE bbsID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, bbsTitle);
			pstmt.setString(2, bbsContent);
			pstmt.setString(3, salary);
			pstmt.setString(4, deadline);
			pstmt.setString(5, category);
			pstmt.setString(6, file);
			pstmt.setString(7, bbs_phone);
			pstmt.setInt(8, bbsID);
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public int delete(int bbsID) {
		String SQL = "UPDATE BBS SET bbsAvailable = 0 WHERE bbsID = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsID);
			return pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터베이스 오류
	}
}
