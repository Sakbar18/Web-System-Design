package user;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Base64;

public class usercon {

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    public usercon() {
        try {
            String url = "jdbc:mysql://localhost:3306/web_sys";
            String user = "root";
            String passwd = "1234";

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, passwd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // SHA-256 해시 함수를 사용하여 비밀번호를 암호화
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int login(String user_id, String passwd) {
        String sql = "SELECT passwd FROM user WHERE user_id = ?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user_id);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                if (hashPassword(passwd).equals(rs.getString(1)))
                    return 1; // 로그인 성공
                else
                    return 0; // 비밀번호 불일치
            }
            return -1; // 아이디 없음
        } catch (Exception e) {
            e.printStackTrace();
            return -2; // 데이터베이스 오류
        }
    }

    public int join(user user) {
        String sql = "INSERT INTO user (username, nickname, user_id, passwd, address, phone) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getNickname());
            pstmt.setString(3, user.getUser_id());

            // 비밀번호 해시 함수 사용
            String hashedPassword = hashPassword(user.getPasswd());
            pstmt.setString(4, hashedPassword);

            // 주소와 전화번호는 그대로 저장
            pstmt.setString(5, user.getAddress());
            pstmt.setString(6, user.getPhone());

            return pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return -1; // 데이터베이스 오류임
        }
    }
}
